/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.11.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../rov/mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.11.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[35];
    char stringdata0[809];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 19), // "serialROV_readyRead"
QT_MOC_LITERAL(2, 31, 0), // ""
QT_MOC_LITERAL(3, 32, 21), // "serialSonic_readyRead"
QT_MOC_LITERAL(4, 54, 21), // "on_openButton_clicked"
QT_MOC_LITERAL(5, 76, 25), // "on_ROVclearButton_clicked"
QT_MOC_LITERAL(6, 102, 21), // "on_X_upButton_clicked"
QT_MOC_LITERAL(7, 124, 23), // "on_X_downButton_clicked"
QT_MOC_LITERAL(8, 148, 21), // "on_Y_upButton_clicked"
QT_MOC_LITERAL(9, 170, 23), // "on_Y_downButton_clicked"
QT_MOC_LITERAL(10, 194, 21), // "on_M_upButton_clicked"
QT_MOC_LITERAL(11, 216, 23), // "on_M_downButton_clicked"
QT_MOC_LITERAL(12, 240, 21), // "on_Z_upButton_clicked"
QT_MOC_LITERAL(13, 262, 23), // "on_Z_downButton_clicked"
QT_MOC_LITERAL(14, 286, 27), // "on_speedResetButton_clicked"
QT_MOC_LITERAL(15, 314, 26), // "on_openSonicButton_clicked"
QT_MOC_LITERAL(16, 341, 26), // "on_sonicSendButton_clicked"
QT_MOC_LITERAL(17, 368, 18), // "on_AButton_clicked"
QT_MOC_LITERAL(18, 387, 18), // "on_DButton_clicked"
QT_MOC_LITERAL(19, 406, 18), // "on_MButton_clicked"
QT_MOC_LITERAL(20, 425, 18), // "on_EButton_clicked"
QT_MOC_LITERAL(21, 444, 31), // "on_clearSonicRecvButton_clicked"
QT_MOC_LITERAL(22, 476, 31), // "on_sonicSendClearButton_clicked"
QT_MOC_LITERAL(23, 508, 24), // "on_vlcSendButton_clicked"
QT_MOC_LITERAL(24, 533, 21), // "on_loopButton_clicked"
QT_MOC_LITERAL(25, 555, 12), // "spi_loopSend"
QT_MOC_LITERAL(26, 568, 20), // "start_spi_LoopThread"
QT_MOC_LITERAL(27, 589, 19), // "stop_spi_LoopThread"
QT_MOC_LITERAL(28, 609, 29), // "on_clearVLCrecvButton_clicked"
QT_MOC_LITERAL(29, 639, 29), // "on_vlcSendClearButton_clicked"
QT_MOC_LITERAL(30, 669, 33), // "on_vlcRecvtextBrowser_textCha..."
QT_MOC_LITERAL(31, 703, 23), // "on_wumalvButton_clicked"
QT_MOC_LITERAL(32, 727, 15), // "wumalv_loopSend"
QT_MOC_LITERAL(33, 743, 28), // "on_clearWumalvButton_clicked"
QT_MOC_LITERAL(34, 772, 36) // "on_clearwumalvSendNumsButton_..."

    },
    "MainWindow\0serialROV_readyRead\0\0"
    "serialSonic_readyRead\0on_openButton_clicked\0"
    "on_ROVclearButton_clicked\0"
    "on_X_upButton_clicked\0on_X_downButton_clicked\0"
    "on_Y_upButton_clicked\0on_Y_downButton_clicked\0"
    "on_M_upButton_clicked\0on_M_downButton_clicked\0"
    "on_Z_upButton_clicked\0on_Z_downButton_clicked\0"
    "on_speedResetButton_clicked\0"
    "on_openSonicButton_clicked\0"
    "on_sonicSendButton_clicked\0"
    "on_AButton_clicked\0on_DButton_clicked\0"
    "on_MButton_clicked\0on_EButton_clicked\0"
    "on_clearSonicRecvButton_clicked\0"
    "on_sonicSendClearButton_clicked\0"
    "on_vlcSendButton_clicked\0on_loopButton_clicked\0"
    "spi_loopSend\0start_spi_LoopThread\0"
    "stop_spi_LoopThread\0on_clearVLCrecvButton_clicked\0"
    "on_vlcSendClearButton_clicked\0"
    "on_vlcRecvtextBrowser_textChanged\0"
    "on_wumalvButton_clicked\0wumalv_loopSend\0"
    "on_clearWumalvButton_clicked\0"
    "on_clearwumalvSendNumsButton_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      33,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  179,    2, 0x08 /* Private */,
       3,    0,  180,    2, 0x08 /* Private */,
       4,    0,  181,    2, 0x08 /* Private */,
       5,    0,  182,    2, 0x08 /* Private */,
       6,    0,  183,    2, 0x08 /* Private */,
       7,    0,  184,    2, 0x08 /* Private */,
       8,    0,  185,    2, 0x08 /* Private */,
       9,    0,  186,    2, 0x08 /* Private */,
      10,    0,  187,    2, 0x08 /* Private */,
      11,    0,  188,    2, 0x08 /* Private */,
      12,    0,  189,    2, 0x08 /* Private */,
      13,    0,  190,    2, 0x08 /* Private */,
      14,    0,  191,    2, 0x08 /* Private */,
      15,    0,  192,    2, 0x08 /* Private */,
      16,    0,  193,    2, 0x08 /* Private */,
      17,    0,  194,    2, 0x08 /* Private */,
      18,    0,  195,    2, 0x08 /* Private */,
      19,    0,  196,    2, 0x08 /* Private */,
      20,    0,  197,    2, 0x08 /* Private */,
      21,    0,  198,    2, 0x08 /* Private */,
      22,    0,  199,    2, 0x08 /* Private */,
      23,    0,  200,    2, 0x08 /* Private */,
      24,    0,  201,    2, 0x08 /* Private */,
      25,    0,  202,    2, 0x08 /* Private */,
      26,    0,  203,    2, 0x08 /* Private */,
      27,    0,  204,    2, 0x08 /* Private */,
      28,    0,  205,    2, 0x08 /* Private */,
      29,    0,  206,    2, 0x08 /* Private */,
      30,    0,  207,    2, 0x08 /* Private */,
      31,    0,  208,    2, 0x08 /* Private */,
      32,    0,  209,    2, 0x08 /* Private */,
      33,    0,  210,    2, 0x08 /* Private */,
      34,    0,  211,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        MainWindow *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->serialROV_readyRead(); break;
        case 1: _t->serialSonic_readyRead(); break;
        case 2: _t->on_openButton_clicked(); break;
        case 3: _t->on_ROVclearButton_clicked(); break;
        case 4: _t->on_X_upButton_clicked(); break;
        case 5: _t->on_X_downButton_clicked(); break;
        case 6: _t->on_Y_upButton_clicked(); break;
        case 7: _t->on_Y_downButton_clicked(); break;
        case 8: _t->on_M_upButton_clicked(); break;
        case 9: _t->on_M_downButton_clicked(); break;
        case 10: _t->on_Z_upButton_clicked(); break;
        case 11: _t->on_Z_downButton_clicked(); break;
        case 12: _t->on_speedResetButton_clicked(); break;
        case 13: _t->on_openSonicButton_clicked(); break;
        case 14: _t->on_sonicSendButton_clicked(); break;
        case 15: _t->on_AButton_clicked(); break;
        case 16: _t->on_DButton_clicked(); break;
        case 17: _t->on_MButton_clicked(); break;
        case 18: _t->on_EButton_clicked(); break;
        case 19: _t->on_clearSonicRecvButton_clicked(); break;
        case 20: _t->on_sonicSendClearButton_clicked(); break;
        case 21: _t->on_vlcSendButton_clicked(); break;
        case 22: _t->on_loopButton_clicked(); break;
        case 23: _t->spi_loopSend(); break;
        case 24: _t->start_spi_LoopThread(); break;
        case 25: _t->stop_spi_LoopThread(); break;
        case 26: _t->on_clearVLCrecvButton_clicked(); break;
        case 27: _t->on_vlcSendClearButton_clicked(); break;
        case 28: _t->on_vlcRecvtextBrowser_textChanged(); break;
        case 29: _t->on_wumalvButton_clicked(); break;
        case 30: _t->wumalv_loopSend(); break;
        case 31: _t->on_clearWumalvButton_clicked(); break;
        case 32: _t->on_clearwumalvSendNumsButton_clicked(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject MainWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MainWindow.data,
      qt_meta_data_MainWindow,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 33)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 33;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 33)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 33;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
