/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.11.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../lab_Qt/mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.11.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[65];
    char stringdata0[1426];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 19), // "serialROV_readyRead"
QT_MOC_LITERAL(2, 31, 0), // ""
QT_MOC_LITERAL(3, 32, 21), // "serialSonic_readyRead"
QT_MOC_LITERAL(4, 54, 21), // "on_openButton_clicked"
QT_MOC_LITERAL(5, 76, 25), // "on_ROVclearButton_clicked"
QT_MOC_LITERAL(6, 102, 21), // "on_X_upButton_clicked"
QT_MOC_LITERAL(7, 124, 23), // "on_X_downButton_clicked"
QT_MOC_LITERAL(8, 148, 21), // "on_Y_upButton_clicked"
QT_MOC_LITERAL(9, 170, 23), // "on_Y_downButton_clicked"
QT_MOC_LITERAL(10, 194, 21), // "on_M_upButton_clicked"
QT_MOC_LITERAL(11, 216, 23), // "on_M_downButton_clicked"
QT_MOC_LITERAL(12, 240, 21), // "on_Z_upButton_clicked"
QT_MOC_LITERAL(13, 262, 23), // "on_Z_downButton_clicked"
QT_MOC_LITERAL(14, 286, 27), // "on_speedResetButton_clicked"
QT_MOC_LITERAL(15, 314, 26), // "on_openSonicButton_clicked"
QT_MOC_LITERAL(16, 341, 26), // "on_sonicSendButton_clicked"
QT_MOC_LITERAL(17, 368, 18), // "on_AButton_clicked"
QT_MOC_LITERAL(18, 387, 18), // "on_DButton_clicked"
QT_MOC_LITERAL(19, 406, 18), // "on_MButton_clicked"
QT_MOC_LITERAL(20, 425, 18), // "on_EButton_clicked"
QT_MOC_LITERAL(21, 444, 31), // "on_clearSonicRecvButton_clicked"
QT_MOC_LITERAL(22, 476, 31), // "on_sonicSendClearButton_clicked"
QT_MOC_LITERAL(23, 508, 24), // "on_vlcSendButton_clicked"
QT_MOC_LITERAL(24, 533, 21), // "on_loopButton_clicked"
QT_MOC_LITERAL(25, 555, 12), // "spi_loopSend"
QT_MOC_LITERAL(26, 568, 20), // "start_spi_LoopThread"
QT_MOC_LITERAL(27, 589, 19), // "stop_spi_LoopThread"
QT_MOC_LITERAL(28, 609, 29), // "on_clearVLCrecvButton_clicked"
QT_MOC_LITERAL(29, 639, 29), // "on_vlcSendClearButton_clicked"
QT_MOC_LITERAL(30, 669, 33), // "on_vlcRecvtextBrowser_textCha..."
QT_MOC_LITERAL(31, 703, 23), // "on_wumalvButton_clicked"
QT_MOC_LITERAL(32, 727, 15), // "wumalv_loopSend"
QT_MOC_LITERAL(33, 743, 28), // "on_clearWumalvButton_clicked"
QT_MOC_LITERAL(34, 772, 36), // "on_clearwumalvSendNumsButton_..."
QT_MOC_LITERAL(35, 809, 29), // "on_startSpiRecvButton_clicked"
QT_MOC_LITERAL(36, 839, 27), // "on_selectFileButton_clicked"
QT_MOC_LITERAL(37, 867, 25), // "on_sendFileButton_clicked"
QT_MOC_LITERAL(38, 893, 8), // "sendFile"
QT_MOC_LITERAL(39, 902, 18), // "updateProgressSend"
QT_MOC_LITERAL(40, 921, 27), // "on_X_sonic_upButton_clicked"
QT_MOC_LITERAL(41, 949, 29), // "on_X_sonic_downButton_clicked"
QT_MOC_LITERAL(42, 979, 27), // "on_Y_sonic_upButton_clicked"
QT_MOC_LITERAL(43, 1007, 29), // "on_Y_sonic_downButton_clicked"
QT_MOC_LITERAL(44, 1037, 27), // "on_M_sonic_upButton_clicked"
QT_MOC_LITERAL(45, 1065, 29), // "on_M_sonic_downButton_clicked"
QT_MOC_LITERAL(46, 1095, 27), // "on_Z_sonic_upButton_clicked"
QT_MOC_LITERAL(47, 1123, 29), // "on_Z_sonic_downButton_clicked"
QT_MOC_LITERAL(48, 1153, 33), // "on_speedreset_sonicButton_cli..."
QT_MOC_LITERAL(49, 1187, 10), // "updateTime"
QT_MOC_LITERAL(50, 1198, 10), // "updateTemp"
QT_MOC_LITERAL(51, 1209, 11), // "write24zero"
QT_MOC_LITERAL(52, 1221, 7), // "vlcsend"
QT_MOC_LITERAL(53, 1229, 5), // "char*"
QT_MOC_LITERAL(54, 1235, 18), // "update_VLC_bitrate"
QT_MOC_LITERAL(55, 1254, 14), // "updateROVSpeed"
QT_MOC_LITERAL(56, 1269, 9), // "autodrive"
QT_MOC_LITERAL(57, 1279, 26), // "on_autodriveButton_clicked"
QT_MOC_LITERAL(58, 1306, 14), // "send_rov_order"
QT_MOC_LITERAL(59, 1321, 28), // "on_initROVsendButton_clicked"
QT_MOC_LITERAL(60, 1350, 28), // "on_initROVrecvButton_clicked"
QT_MOC_LITERAL(61, 1379, 19), // "on_rmButton_clicked"
QT_MOC_LITERAL(62, 1399, 13), // "keyPressEvent"
QT_MOC_LITERAL(63, 1413, 10), // "QKeyEvent*"
QT_MOC_LITERAL(64, 1424, 1) // "e"

    },
    "MainWindow\0serialROV_readyRead\0\0"
    "serialSonic_readyRead\0on_openButton_clicked\0"
    "on_ROVclearButton_clicked\0"
    "on_X_upButton_clicked\0on_X_downButton_clicked\0"
    "on_Y_upButton_clicked\0on_Y_downButton_clicked\0"
    "on_M_upButton_clicked\0on_M_downButton_clicked\0"
    "on_Z_upButton_clicked\0on_Z_downButton_clicked\0"
    "on_speedResetButton_clicked\0"
    "on_openSonicButton_clicked\0"
    "on_sonicSendButton_clicked\0"
    "on_AButton_clicked\0on_DButton_clicked\0"
    "on_MButton_clicked\0on_EButton_clicked\0"
    "on_clearSonicRecvButton_clicked\0"
    "on_sonicSendClearButton_clicked\0"
    "on_vlcSendButton_clicked\0on_loopButton_clicked\0"
    "spi_loopSend\0start_spi_LoopThread\0"
    "stop_spi_LoopThread\0on_clearVLCrecvButton_clicked\0"
    "on_vlcSendClearButton_clicked\0"
    "on_vlcRecvtextBrowser_textChanged\0"
    "on_wumalvButton_clicked\0wumalv_loopSend\0"
    "on_clearWumalvButton_clicked\0"
    "on_clearwumalvSendNumsButton_clicked\0"
    "on_startSpiRecvButton_clicked\0"
    "on_selectFileButton_clicked\0"
    "on_sendFileButton_clicked\0sendFile\0"
    "updateProgressSend\0on_X_sonic_upButton_clicked\0"
    "on_X_sonic_downButton_clicked\0"
    "on_Y_sonic_upButton_clicked\0"
    "on_Y_sonic_downButton_clicked\0"
    "on_M_sonic_upButton_clicked\0"
    "on_M_sonic_downButton_clicked\0"
    "on_Z_sonic_upButton_clicked\0"
    "on_Z_sonic_downButton_clicked\0"
    "on_speedreset_sonicButton_clicked\0"
    "updateTime\0updateTemp\0write24zero\0"
    "vlcsend\0char*\0update_VLC_bitrate\0"
    "updateROVSpeed\0autodrive\0"
    "on_autodriveButton_clicked\0send_rov_order\0"
    "on_initROVsendButton_clicked\0"
    "on_initROVrecvButton_clicked\0"
    "on_rmButton_clicked\0keyPressEvent\0"
    "QKeyEvent*\0e"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      60,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  314,    2, 0x08 /* Private */,
       3,    0,  315,    2, 0x08 /* Private */,
       4,    0,  316,    2, 0x08 /* Private */,
       5,    0,  317,    2, 0x08 /* Private */,
       6,    0,  318,    2, 0x08 /* Private */,
       7,    0,  319,    2, 0x08 /* Private */,
       8,    0,  320,    2, 0x08 /* Private */,
       9,    0,  321,    2, 0x08 /* Private */,
      10,    0,  322,    2, 0x08 /* Private */,
      11,    0,  323,    2, 0x08 /* Private */,
      12,    0,  324,    2, 0x08 /* Private */,
      13,    0,  325,    2, 0x08 /* Private */,
      14,    0,  326,    2, 0x08 /* Private */,
      15,    0,  327,    2, 0x08 /* Private */,
      16,    0,  328,    2, 0x08 /* Private */,
      17,    0,  329,    2, 0x08 /* Private */,
      18,    0,  330,    2, 0x08 /* Private */,
      19,    0,  331,    2, 0x08 /* Private */,
      20,    0,  332,    2, 0x08 /* Private */,
      21,    0,  333,    2, 0x08 /* Private */,
      22,    0,  334,    2, 0x08 /* Private */,
      23,    0,  335,    2, 0x08 /* Private */,
      24,    0,  336,    2, 0x08 /* Private */,
      25,    0,  337,    2, 0x08 /* Private */,
      26,    0,  338,    2, 0x08 /* Private */,
      27,    0,  339,    2, 0x08 /* Private */,
      28,    0,  340,    2, 0x08 /* Private */,
      29,    0,  341,    2, 0x08 /* Private */,
      30,    0,  342,    2, 0x08 /* Private */,
      31,    0,  343,    2, 0x08 /* Private */,
      32,    0,  344,    2, 0x08 /* Private */,
      33,    0,  345,    2, 0x08 /* Private */,
      34,    0,  346,    2, 0x08 /* Private */,
      35,    0,  347,    2, 0x08 /* Private */,
      36,    0,  348,    2, 0x08 /* Private */,
      37,    0,  349,    2, 0x08 /* Private */,
      38,    0,  350,    2, 0x08 /* Private */,
      39,    0,  351,    2, 0x08 /* Private */,
      40,    0,  352,    2, 0x08 /* Private */,
      41,    0,  353,    2, 0x08 /* Private */,
      42,    0,  354,    2, 0x08 /* Private */,
      43,    0,  355,    2, 0x08 /* Private */,
      44,    0,  356,    2, 0x08 /* Private */,
      45,    0,  357,    2, 0x08 /* Private */,
      46,    0,  358,    2, 0x08 /* Private */,
      47,    0,  359,    2, 0x08 /* Private */,
      48,    0,  360,    2, 0x08 /* Private */,
      49,    0,  361,    2, 0x08 /* Private */,
      50,    0,  362,    2, 0x08 /* Private */,
      51,    0,  363,    2, 0x08 /* Private */,
      52,    1,  364,    2, 0x08 /* Private */,
      54,    0,  367,    2, 0x08 /* Private */,
      55,    0,  368,    2, 0x08 /* Private */,
      56,    0,  369,    2, 0x08 /* Private */,
      57,    0,  370,    2, 0x08 /* Private */,
      58,    0,  371,    2, 0x08 /* Private */,
      59,    0,  372,    2, 0x08 /* Private */,
      60,    0,  373,    2, 0x08 /* Private */,
      61,    0,  374,    2, 0x08 /* Private */,
      62,    1,  375,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 53,   52,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 63,   64,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        MainWindow *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->serialROV_readyRead(); break;
        case 1: _t->serialSonic_readyRead(); break;
        case 2: _t->on_openButton_clicked(); break;
        case 3: _t->on_ROVclearButton_clicked(); break;
        case 4: _t->on_X_upButton_clicked(); break;
        case 5: _t->on_X_downButton_clicked(); break;
        case 6: _t->on_Y_upButton_clicked(); break;
        case 7: _t->on_Y_downButton_clicked(); break;
        case 8: _t->on_M_upButton_clicked(); break;
        case 9: _t->on_M_downButton_clicked(); break;
        case 10: _t->on_Z_upButton_clicked(); break;
        case 11: _t->on_Z_downButton_clicked(); break;
        case 12: _t->on_speedResetButton_clicked(); break;
        case 13: _t->on_openSonicButton_clicked(); break;
        case 14: _t->on_sonicSendButton_clicked(); break;
        case 15: _t->on_AButton_clicked(); break;
        case 16: _t->on_DButton_clicked(); break;
        case 17: _t->on_MButton_clicked(); break;
        case 18: _t->on_EButton_clicked(); break;
        case 19: _t->on_clearSonicRecvButton_clicked(); break;
        case 20: _t->on_sonicSendClearButton_clicked(); break;
        case 21: _t->on_vlcSendButton_clicked(); break;
        case 22: _t->on_loopButton_clicked(); break;
        case 23: _t->spi_loopSend(); break;
        case 24: _t->start_spi_LoopThread(); break;
        case 25: _t->stop_spi_LoopThread(); break;
        case 26: _t->on_clearVLCrecvButton_clicked(); break;
        case 27: _t->on_vlcSendClearButton_clicked(); break;
        case 28: _t->on_vlcRecvtextBrowser_textChanged(); break;
        case 29: _t->on_wumalvButton_clicked(); break;
        case 30: _t->wumalv_loopSend(); break;
        case 31: _t->on_clearWumalvButton_clicked(); break;
        case 32: _t->on_clearwumalvSendNumsButton_clicked(); break;
        case 33: _t->on_startSpiRecvButton_clicked(); break;
        case 34: _t->on_selectFileButton_clicked(); break;
        case 35: _t->on_sendFileButton_clicked(); break;
        case 36: _t->sendFile(); break;
        case 37: _t->updateProgressSend(); break;
        case 38: _t->on_X_sonic_upButton_clicked(); break;
        case 39: _t->on_X_sonic_downButton_clicked(); break;
        case 40: _t->on_Y_sonic_upButton_clicked(); break;
        case 41: _t->on_Y_sonic_downButton_clicked(); break;
        case 42: _t->on_M_sonic_upButton_clicked(); break;
        case 43: _t->on_M_sonic_downButton_clicked(); break;
        case 44: _t->on_Z_sonic_upButton_clicked(); break;
        case 45: _t->on_Z_sonic_downButton_clicked(); break;
        case 46: _t->on_speedreset_sonicButton_clicked(); break;
        case 47: _t->updateTime(); break;
        case 48: _t->updateTemp(); break;
        case 49: _t->write24zero(); break;
        case 50: _t->vlcsend((*reinterpret_cast< char*(*)>(_a[1]))); break;
        case 51: _t->update_VLC_bitrate(); break;
        case 52: _t->updateROVSpeed(); break;
        case 53: _t->autodrive(); break;
        case 54: _t->on_autodriveButton_clicked(); break;
        case 55: _t->send_rov_order(); break;
        case 56: _t->on_initROVsendButton_clicked(); break;
        case 57: _t->on_initROVrecvButton_clicked(); break;
        case 58: _t->on_rmButton_clicked(); break;
        case 59: _t->keyPressEvent((*reinterpret_cast< QKeyEvent*(*)>(_a[1]))); break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject MainWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MainWindow.data,
      qt_meta_data_MainWindow,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 60)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 60;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 60)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 60;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
